<?php $__env->startSection('title', 'Parts List'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Parts List</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="table-responsive col-sm-10">
    <table class="table table-hover">
      <thead>
        <tr>
          <th>Id</th>
          <th>Parts Name</th>
          <th>Brand Name</th>
          <th>Price</th>
          <th>Image</th>
          <th>Description</th>
          <th>Edit</th>
        </tr>
      </thead>
      <tbody>
          <?php $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($data->id); ?></td>
              <td><?php echo e($data->part_name); ?></td>
              <td><?php echo e($data->part_brand); ?></td>
              <td><?php echo e($data->part_price); ?></td>
              <td><img src="/images/parts/<?php echo e($data->image); ?>" alt="image" style="width:10%;height:10%;"></td>
              <td><?php echo e($data->part_description); ?></td>
              <td><a href="edit-parts/<?php echo e($data->id); ?>">Edit</a></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>