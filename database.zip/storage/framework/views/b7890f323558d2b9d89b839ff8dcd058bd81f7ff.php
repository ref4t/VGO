<!doctype html>
<html class="no-js" lang="zxx">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Oswan - eCommerce HTML5 Template</title>
        <meta name="description" content="Live Preview Of Oswan eCommerce HTML5 Template">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(URL::asset('bikearena/img/favicon.png')); ?>">

		<!-- all css here -->
        <link rel="stylesheet" href="<?php echo e(URL::asset('bikearena/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('bikearena/css/animate.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('bikearena/css/owl.carousel.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('bikearena/css/chosen.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('bikearena/css/easyzoom.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('bikearena/css/meanmenu.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('bikearena/css/themify-icons.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('bikearena/css/icofont.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('bikearena/css/font-awesome.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('bikearena/css/bundle.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('bikearena/css/style.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('bikearena/css/responsive.css')); ?>">
        <script src="<?php echo e(URL::asset('bikearena/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>
    </head>
    <body>
        <div class="wrapper">
            <header>
                <div class="header-area transparent-bar ptb-55">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-4">
                                <div class="logo-small-device">
                                    <a href="<?php echo e(route('bikearena.index')); ?>"><img alt="" src="<?php echo e(URL::asset('bikearena/img/logo/logo.png')); ?>"></a>
                                </div>
                            </div>
                            <div class="col-lg-8 col-md-8 col-8">
                                <div class="header-contact-menu-wrapper pl-45">
                                    <div class="header-contact">
                                        <p>WANT TO TALK WITH US +01254 265 987</p>
                                    </div>
                                    <div class="menu-wrapper text-center">
                                        <button class="menu-toggle">
                                            <img class="s-open" alt="" src="<?php echo e(URL::asset('bikearena/img/icon-img/menu.png')); ?>">
                                            <img class="s-close" alt="" src="<?php echo e(URL::asset('bikearena/img/icon-img/menu-close.png')); ?>">
                                        </button>
                                        <div class="main-menu">
                                            <nav>
                                                <ul>
                                                    <li><a href="<?php echo e(route('bikearena.index')); ?>">home</a></li>
                                                    <li class="active"><a href="<?php echo e(route('bikearena.about')); ?>">about us </a></li>
                                                    <li><a href="#">shop</a>
                                                        <ul>
                                                            <li><a href="<?php echo e(route('bikearena.shop')); ?>">shop</a></li>
                                                            <li><a href="<?php echo e(route('bikearena.product-details')); ?>">product details</a></li>
                                                            <li><a href="<?php echo e(route('bikearena.checkout')); ?>">checkout</a></li>
                                                            <li><a href="<?php echo e(route('bikearena.wishlist')); ?>">wishlist</a></li>
                                                            <li><a href="<?php echo e(route('bikearena.cart')); ?>">cart</a></li>
                                                        </ul>
                                                    </li>
                                                    <li><a href="#">pages</a>
                                                        <ul>
                                                            <li><a href="<?php echo e(route('bikearena.about')); ?>">about us</a></li>
                                                            <li><a href="<?php echo e(route('bikearena.cart')); ?>">cart page</a></li>
                                                            <li><a href="<?php echo e(route('bikearena.checkout')); ?>">checkout</a></li>
                                                            <li><a href="<?php echo e(route('bikearena.wishlist')); ?>">wishlist</a></li>
                                                            <li><a href="<?php echo e(route('bikearena.login-register')); ?>">login</a></li>
                                                            <li><a href="<?php echo e(route('bikearena.contact')); ?>">contact</a></li>
                                                        </ul>
                                                    </li>
                                                    <li><a href="#">blog</a>
                                                        <ul>
                                                            <li><a href="<?php echo e(route('bikearena.blog')); ?>">blog</a></li>
                                                            <li><a href="<?php echo e(route('bikearena.blog-details')); ?>">blog details</a></li>
                                                        </ul>
                                                    </li>
                                                    <li><a href="<?php echo e(route('bikearena.contact')); ?>">contact us</a></li>
                                                </ul>
                                            </nav>
                                        </div>
                                    </div>
                                </div>
                                <div class="header-cart cart-small-device">
                                    <button class="icon-cart">
                                        <i class="ti-shopping-cart"></i>
                                        <span class="count-style">02</span>
                                        <span class="count-price-add">$295.95</span>
                                    </button>
                                    <div class="shopping-cart-content">
                                        <ul>
                                            <li class="single-shopping-cart">
                                                <div class="shopping-cart-img">
                                                    <a href="#"><img alt="" src="<?php echo e(URL::asset('bikearena/img/cart/cart-1.jpg')); ?>"></a>
                                                </div>
                                                <div class="shopping-cart-title">
                                                    <h3><a href="#">Gloriori GSX 250 R </a></h3>
                                                    <span>Price: $275</span>
                                                    <span>Qty: 01</span>
                                                </div>
                                                <div class="shopping-cart-delete">
                                                    <a href="#"><i class="icofont icofont-ui-delete"></i></a>
                                                </div>
                                            </li>
                                            <li class="single-shopping-cart">
                                                <div class="shopping-cart-img">
                                                    <a href="#"><img alt="" src="<?php echo e(URL::asset('bikearena/img/cart/cart-2.jpg')); ?>"></a>
                                                </div>
                                                <div class="shopping-cart-title">
                                                    <h3><a href="#">Demonissi Gori</a></h3>
                                                    <span>Price: $275</span>
                                                    <span class="qty">Qty: 01</span>
                                                </div>
                                                <div class="shopping-cart-delete">
                                                    <a href="#"><i class="icofont icofont-ui-delete"></i></a>
                                                </div>
                                            </li>
                                            <li class="single-shopping-cart">
                                                <div class="shopping-cart-img">
                                                    <a href="#"><img alt="" src="<?php echo e(URL::asset('bikearena/img/cart/cart-3.jpg')); ?>"></a>
                                                </div>
                                                <div class="shopping-cart-title">
                                                    <h3><a href="#">Demonissi Gori</a></h3>
                                                    <span>Price: $275</span>
                                                    <span class="qty">Qty: 01</span>
                                                </div>
                                                <div class="shopping-cart-delete">
                                                    <a href="#"><i class="icofont icofont-ui-delete"></i></a>
                                                </div>
                                            </li>
                                        </ul>
                                        <div class="shopping-cart-total">
                                            <h4>total: <span>$550.00</span></h4>
                                        </div>
                                        <div class="shopping-cart-btn">
                                            <a class="btn-style cr-btn" href="<?php echo e(route('bikearena.checkout')); ?>">checkout</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mobile-menu-area col-12">
                                <div class="mobile-menu">
                                    <nav id="mobile-menu-active">
                                        <ul class="menu-overflow">
                                            <li><a href="<?php echo e(route('bikearena.index')); ?>">HOME</a></li>
                                            <li><a href="#">pages</a>
                                                <ul>
                                                    <li><a href="<?php echo e(route('bikearena.about')); ?>">about us</a></li>
                                                    <li><a href="<?php echo e(route('bikearena.cart')); ?>">cart page</a></li>
                                                    <li><a href="<?php echo e(route('bikearena.checkout')); ?>">checkout</a></li>
                                                    <li><a href="<?php echo e(route('bikearena.wishlist')); ?>">wishlist</a></li>
                                                    <li><a href="<?php echo e(route('bikearena.login-register')); ?>">login</a></li>
                                                    <li><a href="<?php echo e(route('bikearena.contact')); ?>">contact</a></li>
                                                </ul>
                                            </li>
                                            <li><a href="#">shop</a>
                                                <ul>
                                                    <li><a href="<?php echo e(route('bikearena.shop')); ?>">shop</a></li>
                                                    <li><a href="<?php echo e(route('bikearena.product-details')); ?>">product details</a></li>
                                                    <li><a href="<?php echo e(route('bikearena.checkout')); ?>">checkout</a></li>
                                                    <li><a href="<?php echo e(route('bikearena.wishlist')); ?>">wishlist</a></li>
                                                    <li><a href="<?php echo e(route('bikearena.cart')); ?>">cart</a></li>
                                                </ul>
                                            </li>
                                            <li><a href="#">BLOG</a>
                                                <ul>
                                                    <li><a href="<?php echo e(route('bikearena.blog')); ?>">blog page</a></li>
                                                    <li><a href="<?php echo e(route('bikearena.blog-details')); ?>">blog details</a></li>
                                                </ul>
                                            </li>
                                            <li><a href="<?php echo e(route('bikearena.contact')); ?>"> Contact us</a></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="header-cart-wrapper">
                        <div class="header-cart">
                            <button class="icon-cart">
                                <i class="ti-shopping-cart"></i>
                                <span class="count-style">02</span>
                                <span class="count-price-add">$295.95</span>
                            </button>
                            <div class="shopping-cart-content">
                                <ul>
                                    <li class="single-shopping-cart">
                                        <div class="shopping-cart-img">
                                            <a href="#"><img alt="" src="<?php echo e(URL::asset('bikearena/img/cart/cart-1.jpg')); ?>"></a>
                                        </div>
                                        <div class="shopping-cart-title">
                                            <h3><a href="#">Gloriori GSX 250 R </a></h3>
                                            <span>Price: $275</span>
                                            <span>Qty: 01</span>
                                        </div>
                                        <div class="shopping-cart-delete">
                                            <a href="#"><i class="icofont icofont-ui-delete"></i></a>
                                        </div>
                                    </li>
                                    <li class="single-shopping-cart">
                                        <div class="shopping-cart-img">
                                            <a href="#"><img alt="" src="<?php echo e(URL::asset('bikearena/img/cart/cart-2.jpg')); ?>"></a>
                                        </div>
                                        <div class="shopping-cart-title">
                                            <h3><a href="#">Demonissi Gori</a></h3>
                                            <span>Price: $275</span>
                                            <span class="qty">Qty: 01</span>
                                        </div>
                                        <div class="shopping-cart-delete">
                                            <a href="#"><i class="icofont icofont-ui-delete"></i></a>
                                        </div>
                                    </li>
                                    <li class="single-shopping-cart">
                                        <div class="shopping-cart-img">
                                            <a href="#"><img alt="" src="<?php echo e(URL::asset('bikearena/img/cart/cart-3.jpg')); ?>"></a>
                                        </div>
                                        <div class="shopping-cart-title">
                                            <h3><a href="#">Demonissi Gori</a></h3>
                                            <span>Price: $275</span>
                                            <span class="qty">Qty: 01</span>
                                        </div>
                                        <div class="shopping-cart-delete">
                                            <a href="#"><i class="icofont icofont-ui-delete"></i></a>
                                        </div>
                                    </li>
                                </ul>
                                <div class="shopping-cart-total">
                                    <h4>total: <span>$550.00</span></h4>
                                </div>
                                <div class="shopping-cart-btn">
                                    <a class="btn-style cr-btn" href="<?php echo e(route('bikearena.checkout')); ?>">checkout</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <div class="breadcrumb-area pt-255 pb-170" style="background-image: url(<?php echo e(url('bikearena/img/banner/banner-4.jpg')); ?>)">
                <div class="container-fluid">
                    <div class="breadcrumb-content text-center">
                        <h2>product details </h2>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('bikearena.index')); ?>">home</a>
                            </li>
                            <li>product details </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="product-details-area fluid-padding-3 ptb-130">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="product-details-img-content">
                                <div class="product-details-tab mr-40">
                                    <div class="product-details-large tab-content">
                                        <div class="tab-pane active" id="pro-details1">
                                            <div class="easyzoom easyzoom--overlay">
                                                <a href="<?php echo e(URL::asset('bikearena/img/product-details/bl1.jpg')); ?>">
                                                    <img src="<?php echo e(URL::asset('bikearena/img/product-details/l1.jpg')); ?>" alt="">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="pro-details2">
                                            <div class="easyzoom easyzoom--overlay">
                                                <a href="<?php echo e(URL::asset('bikearena/img/product-details/bl2.jpg')); ?>">
                                                    <img src="<?php echo e(URL::asset('bikearena/img/product-details/l2.jpg')); ?>" alt="">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="pro-details3">
                                            <div class="easyzoom easyzoom--overlay">
                                                <a href="<?php echo e(URL::asset('bikearena/img/product-details/bl3.jpg')); ?>">
                                                    <img src="<?php echo e(URL::asset('bikearena/img/product-details/l3.jpg')); ?>" alt="">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="pro-details4">
                                            <div class="easyzoom easyzoom--overlay">
                                                <a href="<?php echo e(URL::asset('bikearena/img/product-details/bl4.jpg')); ?>">
                                                    <img src="<?php echo e(URL::asset('bikearena/img/product-details/l4.jpg')); ?>" alt="">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="pro-details5">
                                            <div class="easyzoom easyzoom--overlay">
                                                <a href="<?php echo e(URL::asset('bikearena/img/product-details/bl3.jpg')); ?>">
                                                    <img src="<?php echo e(URL::asset('bikearena/img/product-details/l3.jpg')); ?>" alt="">
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="product-details-small nav mt-12 product-dec-slider owl-carousel">
                                        <a class="active" href="#pro-details1">
                                            <img src="<?php echo e(URL::asset('bikearena/img/product-details/s1.jpg')); ?>" alt="">
                                        </a>
                                        <a href="#pro-details2">
                                            <img src="<?php echo e(URL::asset('bikearena/img/product-details/s2.jpg')); ?>" alt="">
                                        </a>
                                        <a href="#pro-details3">
                                            <img src="<?php echo e(URL::asset('bikearena/img/product-details/s3.jpg')); ?>" alt="">
                                        </a>
                                        <a href="#pro-details4">
                                            <img src="<?php echo e(URL::asset('bikearena/img/product-details/s4.jpg')); ?>" alt="">
                                        </a>
                                        <a href="#pro-details5">
                                            <img src="<?php echo e(URL::asset('bikearena/img/product-details/s3.jpg')); ?>" alt="">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="product-details-content">
                                <h2>Klager GSX 250 R</h2>
                                <div class="quick-view-rating">
                                    <i class="fa fa-star reting-color"></i>
                                    <i class="fa fa-star reting-color"></i>
                                    <i class="fa fa-star reting-color"></i>
                                    <i class="fa fa-star reting-color"></i>
                                    <i class="fa fa-star reting-color"></i>
                                    <span> ( 01 Customer Review )</span>
                                </div>
                                <div class="product-price">
                                    <span>$2549</span>
                                </div>
                                <div class="product-overview">
                                    <h5 class="pd-sub-title">Product Overview</h5>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipic it, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercita tion ullamco laboris nisi ut aliquip ex ea commodo.</p>
                                </div>
                                <div class="product-color">
                                    <h5 class="pd-sub-title">Product color</h5>
                                    <ul>
                                        <li class="red">b</li>
                                        <li class="pink">p</li>
                                        <li class="blue">b</li>
                                        <li class="sky2">b</li>
                                        <li class="green">y</li>
                                        <li class="purple2">g</li>
                                    </ul>
                                </div>
                                <div class="quickview-plus-minus">
                                    <div class="cart-plus-minus">
                                        <input type="text" value="02" name="qtybutton" class="cart-plus-minus-box">
                                    </div>
                                    <div class="quickview-btn-cart">
                                        <a class="btn-style cr-btn" href="#"><span>add to cart</span></a>
                                    </div>
                                    <div class="quickview-btn-wishlist">
                                        <a class="btn-hover cr-btn" href="#"><span><i class="icofont icofont-heart-alt"></i></span></a>
                                    </div>
                                </div>
                                <div class="product-categories">
                                    <h5 class="pd-sub-title">Categories</h5>
                                    <ul>
                                        <li>
                                            <a href="#">fashion ,</a>
                                        </li>
                                        <li>
                                            <a href="#">electronics ,</a>
                                        </li>
                                        <li>
                                            <a href="#">toys ,</a>
                                        </li>
                                        <li>
                                            <a href="#">food ,</a>
                                        </li>
                                        <li>
                                            <a href="#">jewellery </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="product-share">
                                    <h5 class="pd-sub-title">Share</h5>
                                    <ul>
                                        <li>
                                            <a href="#"><i class="icofont icofont-social-facebook"></i></a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="icofont icofont-social-twitter"></i></a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="icofont icofont-social-pinterest"></i></a>
                                        </li>
                                        <li>
                                            <a href="#"> <i class="icofont icofont-social-instagram"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="newsletter-area">
                <div class="container">
                    <div class="newsletter-wrapper-all theme-bg-2">
                        <div class="row">
                            <div class="col-lg-5 col-12 col-md-12">
                                <div class="newsletter-img bg-img" style="background-image: url(<?php echo e(url('bikearena/img/banner/newsletter-bg.png')); ?>)">
                                    <img alt="image" src="<?php echo e(URL::asset('bikearena/img/team/newsletter-img.png')); ?>">
                                </div>
                            </div>
                            <div class="col-lg-7 col-12 col-md-12">
                                <div class="newsletter-wrapper text-center">
                                    <div class="newsletter-title">
                                        <h3>Subscribe our newsletter</h3>
                                    </div>
                                    <div id="mc_embed_signup" class="subscribe-form">
                                        <form action="#" method="post" id="#" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
                                            <div id="mc_embed_signup_scroll" class="mc-form">
                                                <input type="email" value="" name="EMAIL" class="email" placeholder="Enter your email here..." required>
                                                <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                                                <div class="mc-news" aria-hidden="true"><input type="text" name="b_6bbb9b6f5827bd842d9640c82_05d85f18ef" tabindex="-1" value=""></div>
                                                <div class="clear"><input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="button"></div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <footer>
                <div class="footer-top pt-210 pb-98 theme-bg">
                    <div class="container">
                       <div class="row">
                            <div class="col-lg-3 col-md-6 col-12">
                                <div class="footer-widget mb-30">
                                    <div class="footer-logo">
                                        <a href="<?php echo e(route('bikearena.index')); ?>">
                                            <img src="<?php echo e(URL::asset('bikearena/img/logo/2.png')); ?>" alt="">
                                        </a>
                                    </div>
                                    <div class="footer-about">
                                        <p><span>OSWAN</span> the most latgest bike store in the wold can serve you latest ulity of motorcycle soucan sell here your motorcycle it quo </p>
                                        <div class="footer-support">
                                            <h5>FOR SUPPORT</h5>
                                            <span> 01245 658 698 (Toll Free)</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-12">
                                <div class="footer-widget mb-30 pl-60">
                                    <div class="footer-widget-title">
                                        <h3>QUICK LINK</h3>
                                    </div>
                                    <div class="quick-links">
                                        <ul>
                                            <li><a href="<?php echo e(route('bikearena.about')); ?>">About us</a></li>
                                            <li><a href="#">Service</a></li>
                                            <li><a href="#">Inventory</a></li>
                                            <li><a href="<?php echo e(route('bikearena.shop')); ?>">Shop</a></li>
                                            <li><a href="<?php echo e(route('bikearena.blog')); ?>">Blog</a></li>
                                            <li><a href="#">Conditions</a></li>
                                            <li><a href="<?php echo e(route('bikearena.contact')); ?>">Contact</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-12">
                                <div class="footer-widget mb-30">
                                    <div class="footer-widget-title">
                                        <h3>LATEST TWEET</h3>
                                    </div>
                                    <div class="food-widget-content pr-30">
                                        <div class="single-tweet">
                                            <p><a href="#">@Smith,</a> the most latgest bike store in the wold can serve you 10 min ago</p>
                                        </div>
                                        <div class="single-tweet">
                                            <p><a href="#">@Smith,</a> the most latgest bike store in the wold can serve you 10 min ago</p>
                                        </div>
                                        <div class="single-tweet">
                                            <p><a href="#">@Smith,</a> the most latgest bike store in the wold can serve you 10 min ago</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-12">
                                <div class="footer-widget mb-30">
                                    <div class="footer-widget-title">
                                        <h3>CONTACT INFO</h3>
                                    </div>
                                    <div class="food-info-wrapper">
                                        <div class="food-address">
                                            <div class="food-info-title">
                                                <span>Address</span>
                                            </div>
                                            <div class="food-info-content">
                                                <p>276 Jhilli Nogor, 4th folor, Momen Tower, Main Town, New Yourk</p>
                                            </div>
                                        </div>
                                        <div class="food-address">
                                            <div class="food-info-title">
                                                <span>Phone</span>
                                            </div>
                                            <div class="food-info-content">
                                                <p>+090 12568 369 987</p>
                                                <p>+090 12568 369 987</p>
                                            </div>
                                        </div>
                                        <div class="food-address">
                                            <div class="food-info-title">
                                                <span>Web</span>
                                            </div>
                                            <div class="food-info-content">
                                                <a href="#">info@oswanmega.com</a>
                                                <a href="#">www.oswanmega.com</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-bottom ptb-35 black-bg">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-8 col-12">
                                <div class="copyright">
                                    <p>©Copyright, 2018 All Rights Reserved by <a href="https://freethemescloud.com/">Free themes Cloud</a></p>
                                </div>
                            </div>
                            <div class="col-md-4 col-12">
                                <div class="footer-payment-method">
                                    <a href="#"><img alt="" src="<?php echo e(URL::asset('bikearena/img/icon-img/payment.png')); ?>"></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>

		<!-- all js here -->
        <script src="<?php echo e(URL::asset('bikearena/js/vendor/jquery-1.12.0.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('bikearena/js/popper.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('bikearena/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('bikearena/js/isotope.pkgd.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('bikearena/js/imagesloaded.pkgd.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('bikearena/js/jquery.counterup.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('bikearena/js/waypoints.min.js')); ?>"></script>

        <script src="<?php echo e(URL::asset('bikearena/js/owl.carousel.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('bikearena/js/plugins.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('bikearena/js/main.js')); ?>"></script>
    </body>
</html>
