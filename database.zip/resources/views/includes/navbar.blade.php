<head>
    <link rel="stylesheet" href="{!! asset('css/navbar.css') !!}">
</head>


    <div class="nav">
    <input type="checkbox" id="nav-check">
    <div class="nav-header">
        <div class="nav-title">
            VgoBD
        </div>
    </div>
    <div class="nav-btn">
        <label for="nav-check">
            <span></span>
            <span></span>
            <span></span>
        </label>
    </div>

    <div class="nav-links">
        <a href="" target="_blank">Services</a>
        <a href="" target="_blank">Bike Arena</a>
        <a href="" target="_blank">About</a>
        <a href="" target="_blank">Contact</a>
        <a href="" target="_blank">Login</a>
    </div>
</div>